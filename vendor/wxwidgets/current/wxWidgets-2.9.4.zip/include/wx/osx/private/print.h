#ifdef __WXMAC_CLASSIC__
#include "wx/osx/classic/private/print.h"
#else
#include "wx/osx/carbon/private/print.h"
#endif
