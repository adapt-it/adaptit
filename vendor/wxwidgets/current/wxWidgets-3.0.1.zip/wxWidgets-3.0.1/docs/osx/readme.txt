Welcome to wxWidgets/Mac

More Information is available from the wxWidgets project home page at

http://www.wxwidgets.org 

For more information, please see install.txt, todo.txt, and the
manuals.

Please send problems concerning installation, feature requests, 
bug reports or comments to the wxWidgets users list. Information 
on how to subscribe is available from the wxWidgets.org homepage.

Questions/Problems related directly to the mac port can be sent directly
csomor@advancedconcepts.ch.

wxWidgets/Mac doesn't come with any guarantee whatsoever. It 
might crash your harddisk or destroy your monitor. It doesn't 
claim to be suitable for any special or general purpose.

Regards,

Stefan Csomor

